using System;

namespace SwapNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int firstNumber = 3; int secondNumber = 9;
            Console.WriteLine("Before Swap:");
            Console.WriteLine("1st Number: " + firstNumber);
            Console.WriteLine("2nd Number:" + secondNumber);
            Console.WriteLine();
            Console.WriteLine("After Swap:");
            firstNumber = firstNumber * secondNumber;       
            secondNumber = firstNumber / secondNumber;       
            firstNumber = firstNumber / secondNumber; 
            Console.WriteLine("1st Number: "+ firstNumber);
            Console.WriteLine("2nd Number:"+ secondNumber);
        }
    }
}