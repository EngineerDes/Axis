using System;
using System.IO;
using System.Linq;

namespace ReadLines
{
    class Program
    {
        static void Main(string[] args)
        {
            int counter = 1;

            // Read the file and display it line by line.  
            foreach (string line in System.IO.File.ReadLines(@"c:\myfile.txt"))
            {
                System.Console.WriteLine(counter + ". " + line);
                counter++;
            }
            int temp = counter - 1;
            System.Console.WriteLine("There were {0} lines.", temp);
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Chose line from all {0} lines. ", temp + " by entering the corresponding number in each of sentences above:");



            // Suspend the screen  and  Type in your selected line
            Console.WriteLine("Enter Line  to be read:");

            // Create a integer value for selected 
            string lineNumberTemp = Console.ReadLine();
            int lineNo = Convert.ToInt32(lineNumberTemp) -1;

           
            string lineToRead= File.ReadLines(@"c:\myfile.txt").Skip(lineNo).Take(1).First();

            Console.WriteLine();
            Console.WriteLine(" You have selected Line " + lineNumberTemp + " and it reads:");
            Console.WriteLine();
            Console.WriteLine(lineToRead);
        }
    }
}