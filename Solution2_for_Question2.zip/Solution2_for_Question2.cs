using System;
using System.Linq;

namespace SortMarks
{
    class Program
    {
        public static void Main()
        {
            Console.WriteLine("Original Marks Set in their order: ");
            int[] marks = { 70, 90, 20, 60, 10 };
            foreach (int i in marks)
            { 
                Console.WriteLine("{0} ", i);
            }
            Console.WriteLine();
            Console.WriteLine("Updated Marks Sorted in descending order: ");
            int[] sortedMarks = marks;
            sortedMarks = sortedMarks.OrderByDescending(c => c).ToArray();
            foreach (int j in sortedMarks)
            {
                Console.WriteLine("{0} ", j);
            }


        }
    }
}
